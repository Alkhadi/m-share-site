// Legacy duplicate file (not referenced by any page). Kept as a harmless stub.
// The site uses the root-level `app.js` and unified header/footer scripts.
